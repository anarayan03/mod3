package com.cg.jpastart.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity //mendatory
@Table(name="stu_record")
public class Bean implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	@Id //if we use @id it will become primary key;
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int distId;
	private String source;
	private String destination;
	private int dist_in_km;
	private int dist_in_miles;
	public int getDistId() {
		return distId;
	}
	public void setDistId(int distId) {
		this.distId = distId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getDist_in_km() {
		return dist_in_km;
	}
	public void setDist_in_km(int dist_in_km) {
		this.dist_in_km = dist_in_km;
	}
	public int getDist_in_miles() {
		return dist_in_miles;
	}
	public void setDist_in_miles(int dist_in_miles) {
		this.dist_in_miles = dist_in_miles;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	public String toString() {
		return "Bean [distId=" + distId + ", source=" + source + ", destination=" + destination + ", dist_in_km="
				+ dist_in_km + ", dist_in_miles=" + dist_in_miles + "]";
	}
	
}
