package com.cg.jpastart.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class JPQLMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory factory = 
				Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		String sql = "SELECT dist_in_km FROM distance_calculator";
		TypedQuery<Bean> query = (TypedQuery<Bean>) em.createQuery(sql);
		//List<Student> list = query.getResultList();
		/*for(Student obj : list)
		{
			System.out.println("id = "+obj.getStudentId());
			System.out.println("name = "+obj.getName());
		}*/
		Bean bean = (Bean) query.getSingleResult();
		System.out.println("distance_id = "+bean.getDistId());
		System.out.println("source = "+bean.getSource());
		System.out.println("destination = "+bean.getDestination());
		System.out.println("dist_in_km = "+bean.getDist_in_km());
		System.out.println("dist_in_miles = "+bean.getDist_in_miles());
		em.getTransaction().begin();
		String sql1 = "UPDATE distance_calculator  dist_in_km SET dist_in_km.dist_in_km = : distance WHERE dist_in_km.distance_id=:distance_id";
		Query query1 = em.createQuery(sql);
		query1.setParameter("sName", "Bharati");
		query1.setParameter("id", 4);
		int row = query1.executeUpdate();
		System.out.println(row);
		
	}

}
