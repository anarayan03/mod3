package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Distance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory factory =
				Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = 
				factory.createEntityManager();
		Bean obj = em.find(Bean.class, 101);
		System.out.println("id = "+obj.getDistId());
		//System.out.println("name ="+obj.getName());
		//obj.setName("Bharati");
		em.getTransaction().begin();
		em.merge(obj);
		em.getTransaction().commit();
		em.close();
	}

}
